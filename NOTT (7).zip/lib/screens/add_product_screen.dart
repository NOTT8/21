import 'package:flutter/material.dart';
import '../services/api_service.dart';

class AddProductScreen extends StatefulWidget {
  const AddProductScreen({super.key});
  @override
  State<AddProductScreen> createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
  final TextEditingController _name = TextEditingController();
  final TextEditingController _price = TextEditingController();
  final TextEditingController _qty = TextEditingController();
  final TextEditingController _image =
      TextEditingController(); // ✅ คอนโทรลเลอร์สำหรับ URL รูปภาพ

  void _save() async {
    // 1. ตรวจสอบค่าว่าง (แก้ไข syntax ที่พิมพ์ผิด)
    if (_name.text.trim().isEmpty ||
        _price.text.trim().isEmpty ||
        _qty.text.trim().isEmpty ||
        _image.text.trim().isEmpty) {
      // ✅ แก้จาก .isempty เป็น .isEmpty

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("กรุณากรอกข้อมูลให้ครบทุกช่อง")),
      );
      return;
    }

    try {
      // 2. เรียกใช้ ApiService (ส่งค่าให้ครบ 4 ตัวแปรตามที่เขียนไว้ใน Service)
      bool success = await ApiService().addProduct(
        _name.text.trim(),
        _price.text.trim(),
        _qty.text.trim(),
        _image.text.trim(),
      );

      if (!mounted) return;

      if (success) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("บันทึกข้อมูลสำเร็จ")),
        );
        Navigator.pop(context); // กลับหน้าหลัก
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content:
                  Text("เพิ่มข้อมูลไม่สำเร็จ! กรุณาเช็ค Database หรือ PHP")),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("เกิดข้อผิดพลาด: $e")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("เพิ่มสินค้าใหม่")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(
            children: [
              TextField(
                controller: _name,
                decoration: const InputDecoration(
                    labelText: "ชื่อสินค้า",
                    prefixIcon: Icon(Icons.shopping_bag)),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _price,
                decoration: const InputDecoration(
                    labelText: "ราคา", prefixIcon: Icon(Icons.attach_money)),
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _qty,
                decoration: const InputDecoration(
                    labelText: "จำนวน", prefixIcon: Icon(Icons.inventory)),
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 10),
              // ✅ เพิ่มช่องกรอก URL รูปภาพ
              TextField(
                controller: _image,
                decoration: const InputDecoration(
                    labelText: "URL รูปภาพสินค้า",
                    prefixIcon: Icon(Icons.link),
                    hintText: "หามาจ้า"),
              ),
              const SizedBox(height: 30),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _save,
                  child: const Text("บันทึกข้อมูล"),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
