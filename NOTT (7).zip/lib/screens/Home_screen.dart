import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart'; // ✅ ต้อง import ตัวนี้เพิ่ม
import '../services/api_service.dart';
import 'add_product_screen.dart';
import 'login_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool isAdmin = false; // ✅ ตัวแปรเก็บสถานะแอดมิน

  @override
  void initState() {
    super.initState();
    _checkRole(); // ✅ เช็กสิทธิ์ทันทีที่เปิดหน้านี้
  }

  // ✅ ฟังก์ชันเช็กสิทธิ์จากที่บันทึกไว้ตอน Login
  Future<void> _checkRole() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      // สมมติว่าตอน Login คุณบันทึก role ไว้ใน key ชื่อ 'role'
      isAdmin = prefs.getString('role') == 'admin';
    });
  }

  void _showEditDialog(Map<String, dynamic> item) {
    final nameController = TextEditingController(text: item['name'].toString());
    final priceController =
        TextEditingController(text: item['price'].toString());
    final qtyController = TextEditingController(text: item['qty'].toString());
    final imageController =
        TextEditingController(text: item['image']?.toString() ?? '');

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("แก้ไขข้อมูลสินค้า"),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                  controller: nameController,
                  decoration: const InputDecoration(labelText: "ชื่อสินค้า")),
              TextField(
                  controller: priceController,
                  decoration: const InputDecoration(labelText: "ราคา"),
                  keyboardType: TextInputType.number),
              TextField(
                  controller: qtyController,
                  decoration: const InputDecoration(labelText: "จำนวน"),
                  keyboardType: TextInputType.number),
              TextField(
                  controller: imageController,
                  decoration:
                      const InputDecoration(labelText: "URL รูปภาพสินค้า"),
                  keyboardType: TextInputType.url),
            ],
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("ยกเลิก")),
          ElevatedButton(
            onPressed: () async {
              bool success = await ApiService().updateProduct(
                int.parse(item['id'].toString()),
                nameController.text,
                priceController.text,
                qtyController.text,
                imageController.text,
              );
              if (success) {
                if (!mounted) return;
                Navigator.pop(context);
                setState(() {});
                ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text("แก้ไขสำเร็จ!")));
              }
            },
            child: const Text("บันทึก"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("คลังสินค้าของเรา",
            style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.blueAccent, Colors.purpleAccent],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              // ✅ ล้างข้อมูลตอน Logout
              final prefs = await SharedPreferences.getInstance();
              await prefs.clear();
              if (!mounted) return;
              Navigator.pushReplacement(context,
                  MaterialPageRoute(builder: (c) => const LoginScreen()));
            },
          ),
        ],
      ),
      body: FutureBuilder<List<dynamic>>(
        future: ApiService().getProducts(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text("เกิดข้อผิดพลาด: ${snapshot.error}"));
          }
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text("ไม่มีสินค้าในคลัง"));
          }

          return ListView.builder(
            padding: const EdgeInsets.all(10),
            itemCount: snapshot.data!.length,
            itemBuilder: (context, index) {
              final item = snapshot.data![index];
              return Card(
                elevation: 4,
                margin: const EdgeInsets.only(bottom: 12),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15)),
                child: ListTile(
                  leading: Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.blue.shade50,
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: (item['image'] != null &&
                              item['image'].toString().startsWith('http'))
                          ? Image.network(
                              item['image'].toString(),
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) =>
                                  const Icon(Icons.inventory_2,
                                      color: Colors.blueAccent),
                            )
                          : const Icon(Icons.inventory_2,
                              color: Colors.blueAccent),
                    ),
                  ),
                  title: Text(item['name'] ?? 'ไม่มีชื่อ',
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 18)),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("ราคา: ฿${item['price']}",
                          style: const TextStyle(
                              color: Colors.green,
                              fontWeight: FontWeight.w600)),
                      Text("คงเหลือ: ${item['qty']} ชิ้น",
                          style: TextStyle(color: Colors.grey.shade600)),
                    ],
                  ),
                  // ✅ แก้ไขตรงนี้: ถ้าไม่ใช่ admin จะไม่โชว์ปุ่มแก้ไขและลบ
                  trailing: isAdmin
                      ? Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.edit,
                                  color: Colors.blueAccent),
                              onPressed: () => _showEditDialog(item),
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete_forever,
                                  color: Colors.redAccent),
                              onPressed: () => _confirmDelete(item),
                            ),
                          ],
                        )
                      : null, // ถ้าไม่ใช่แอดมิน ให้เป็นค่าว่าง
                ),
              );
            },
          );
        },
      ),
      // ✅ แก้ไขตรงนี้: ถ้าไม่ใช่ admin จะไม่โชว์ปุ่มเพิ่มสินค้า
      floatingActionButton: isAdmin
          ? FloatingActionButton.extended(
              backgroundColor: Colors.purpleAccent,
              onPressed: () async {
                await Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (c) => const AddProductScreen()));
                setState(() {});
              },
              label: const Text("เพิ่มสินค้า"),
              icon: const Icon(Icons.add),
            )
          : null,
    );
  }

  // แยกฟังก์ชันลบออกมาเพื่อให้โค้ดดูสะอาดขึ้น
  void _confirmDelete(Map<String, dynamic> item) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("ยืนยันการลบ"),
        content: Text("คุณต้องการลบ ${item['name']} ใช่หรือไม่?"),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("ยกเลิก")),
          TextButton(
            onPressed: () async {
              await ApiService()
                  .deleteProduct(int.parse(item['id'].toString()));
              if (!mounted) return;
              Navigator.pop(context);
              setState(() {});
            },
            child: const Text("ลบ", style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}
