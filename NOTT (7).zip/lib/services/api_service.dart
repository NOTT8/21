import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  // ✅ ใช้ URL ngrok เดิมของคุณ
  final String baseUrl =
      "https://misleading-unexpeditiously-exie.ngrok-free.dev//api";

  // 1. ฟังก์ชันดึงข้อมูลสินค้า (คงเดิม)
  Future<List<dynamic>> getProducts() async {
    try {
      final response = await http.get(
        Uri.parse("$baseUrl/get_products.php"),
        headers: {"ngrok-skip-browser-warning": "true"},
      );
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      }
    } catch (e) {
      print("Error fetching products: $e");
    }
    return [];
  }

  // 2. ฟังก์ชันสมัครสมาชิก (คงเดิม)
  Future<bool> register(String email, String password) async {
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/register.php"),
        headers: {
          "Content-Type": "application/json",
          "ngrok-skip-browser-warning": "true"
        },
        body: jsonEncode({"email": email, "password": password}),
      );
      return response.statusCode == 200 && response.body.contains("success");
    } catch (e) {
      return false;
    }
  }

  // 3. ✅ ฟังก์ชัน Login (แก้ไขเพื่อรองรับระบบ Admin)
  Future<dynamic> login(String email, String password) async {
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/login.php"),
        headers: {
          "Content-Type": "application/json",
          "ngrok-skip-browser-warning": "true"
        },
        body: jsonEncode({"email": email, "password": password}),
      );

      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);
        if (data['status'] == "success") {
          // ✅ คืนค่า role ('admin' หรือ 'user') กลับไปที่หน้า LoginScreen
          return data['role'];
        }
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  // 4. ฟังก์ชันเพิ่มสินค้า (คงเดิม)
  Future<bool> addProduct(
      String name, String price, String qty, String image) async {
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/add_product.php"),
        headers: {
          "Content-Type": "application/json",
          "ngrok-skip-browser-warning": "true"
        },
        body: jsonEncode({
          "name": name,
          "price": price,
          "qty": qty,
          "image": image,
        }),
      );
      return response.body.contains("success");
    } catch (e) {
      return false;
    }
  }

  // 5. ฟังก์ชันลบสินค้า (คงเดิม)
  Future<bool> deleteProduct(int id) async {
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/delete_product.php"),
        headers: {
          "Content-Type": "application/json",
          "ngrok-skip-browser-warning": "true"
        },
        body: jsonEncode({"id": id}),
      );
      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }

  // 6. ฟังก์ชันแก้ไขสินค้า (คงเดิม)
  Future<bool> updateProduct(
      int id, String name, String price, String qty, String image) async {
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/update_product.php"),
        headers: {
          "Content-Type": "application/json",
          "ngrok-skip-browser-warning": "true"
        },
        body: jsonEncode({
          "id": id,
          "name": name,
          "price": price,
          "qty": qty,
          "image": image
        }),
      );
      return response.statusCode == 200 && response.body.contains("success");
    } catch (e) {
      return false;
    }
  }
}
