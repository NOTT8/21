package com.example.nott

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
