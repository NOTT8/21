import 'package:flutter/material.dart';
import '../services/api_service.dart';
import 'Home_screen.dart'; // ตรวจสอบว่าชื่อไฟล์ตัวพิมพ์เล็กใหญ่ตรงกับในเครื่อง
import 'register_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _userController = TextEditingController();
  final TextEditingController _passController = TextEditingController();
  bool _isLoading = false; // เพิ่มสถานะการโหลด

  void _login() async {
    if (_userController.text.trim().isEmpty ||
        _passController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("กรุณากรอก Email และ Password")),
      );
      return;
    }

    setState(() => _isLoading = true);

    // เชื่อมต่อ API ผ่าน ApiService
    bool success = await ApiService()
        .login(_userController.text.trim(), _passController.text.trim());
    if (!mounted) return;
    setState(() => _isLoading = false);

    if (success) {
      // เมื่อสำเร็จให้นำทางไปหน้า Home และลบหน้า Login ออกจาก Stack
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const HomeScreen()),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("อีเมลหรือรหัสผ่านไม่ถูกต้อง")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    var children2 = [
      const Icon(
        Icons.lock_person_rounded,
        size: 100,
        color: Colors.blueAccent,
      ),
      const SizedBox(height: 10),
      const Text(
        "ระบบคลังสินค้า",
        style: TextStyle(
          fontSize: 22,
          fontWeight: FontWeight.bold,
          color: Colors.blueGrey,
        ),
      ),
      const SizedBox(height: 40),
      _buildTextField(_userController, "Email", Icons.email_outlined),
      const SizedBox(height: 15),
      _buildTextField(_passController, "Password", Icons.lock_outline,
          obscure: true),
      const SizedBox(height: 30),
      _isLoading ? const CircularProgressIndicator() : _buildLoginButton(),
      const SizedBox(height: 15),
      TextButton(
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (c) => const RegisterScreen()),
        ),
        child: const Text(
          "ยังไม่มีบัญชี? สมัครสมาชิกที่นี่",
          style: TextStyle(
            color: Colors.purpleAccent,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    ];
    return Scaffold(
      // แก้ไขเป็น appBar (ตัว B ใหญ่) เพื่อให้หายแดง
      appBar: AppBar(
        title: const Text(
          "ยินดีต้อนรับ",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.blueAccent, Colors.purpleAccent],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
      body: Container(
        color: Colors.grey.shade50,
        padding: const EdgeInsets.all(25),
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: children2,
            ),
          ),
        ),
      ),
    );
  }

  // แยก Widget ปุ่มกดออกมาเพื่อให้จัดเรียงง่ายขึ้น
  Widget _buildLoginButton() {
    return GestureDetector(
      onTap: _login,
      child: Container(
        height: 55,
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Colors.blueAccent, Colors.purpleAccent],
          ),
          borderRadius: BorderRadius.circular(15),
          boxShadow: [
            BoxShadow(
              color: Colors.purpleAccent.withOpacity(0.3),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: const Center(
          child: Text(
            "เข้าสู่ระบบ",
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(
      TextEditingController controller, String label, IconData icon,
      {bool obscure = false}) {
    return TextField(
      controller: controller,
      obscureText: obscure,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: Colors.blueAccent),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15)),
        filled: true,
        fillColor: Colors.white,
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(color: Colors.grey.shade300),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: const BorderSide(color: Colors.blueAccent, width: 2),
        ),
      ),
    );
  }
}
