import 'package:flutter/material.dart';
import 'screens/login_screen.dart'; // เรียกไฟล์ที่คุณเพิ่งวางโค้ด

void main() {
  runApp(const MaterialApp(
    home: LoginScreen(), // กำหนดให้ LoginScreen เป็นหน้าแรก
    debugShowCheckedModeBanner: false,
  ));
}
