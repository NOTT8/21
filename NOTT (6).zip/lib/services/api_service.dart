import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  // ✅ ใช้ /api ตามที่ระบบ ngrok ของคุณตอบรับ 200 OK
  final String baseUrl =
      "https://misleading-unexpeditiously-exie.ngrok-free.dev/api";

  // 1. ฟังก์ชันดึงข้อมูลสินค้า (แก้ปัญหา "ไม่มีสินค้าในคลัง")
  Future<List<dynamic>> getProducts() async {
    try {
      final response = await http.get(
        Uri.parse("$baseUrl/get_products.php"),
        headers: {"ngrok-skip-browser-warning": "true"},
      );
      if (response.statusCode == 200) {
        // คืนค่าเป็น List เพื่อให้ UI ไอคอนกล่องแสดงผลได้
        return jsonDecode(response.body);
      }
    } catch (e) {
      print("Error fetching products: $e");
    }
    return [];
  }

  // 2. ฟังก์ชันสมัครสมาชิก (แก้ตัวแดงหน้า Register และแก้ปัญหา "สมัครไม่สำเร็จ")
  Future<bool> register(String email, String password) async {
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/register.php"),
        headers: {
          "Content-Type": "application/json",
          "ngrok-skip-browser-warning": "true"
        },
        body: jsonEncode({"email": email, "password": password}),
      );
      // เช็คว่า PHP ส่งคำว่า success กลับมาหรือไม่
      return response.statusCode == 200 && response.body.contains("success");
    } catch (e) {
      return false;
    }
  }

  // 3. ฟังก์ชัน Login
  Future<bool> login(String email, String password) async {
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/login.php"),
        headers: {
          "Content-Type": "application/json",
          "ngrok-skip-browser-warning": "true"
        },
        body: jsonEncode({"email": email, "password": password}),
      );
      return response.body.contains("success");
    } catch (e) {
      return false;
    }
  }

  // 4. ฟังก์ชันเพิ่มสินค้า (ส่ง 'image': '' เพื่อไม่ให้โครงสร้างตารางเสีย)
  Future<bool> addProduct(
      String name, String price, String qty, String image) async {
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/add_product.php"),
        headers: {
          "Content-Type": "application/json",
          "ngrok-skip-browser-warning": "true"
        },
        body: jsonEncode({
          "name": name,
          "price": price,
          "qty": qty,
          "image": image,
        }),
      );
      return response.body.contains("success");
    } catch (e) {
      return false;
    }
  }

  // 5. ฟังก์ชันลบสินค้า (คงไว้เพื่อให้ปุ่มถังขยะทำงานได้)
  Future<bool> deleteProduct(int id) async {
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/delete_product.php"),
        headers: {
          "Content-Type": "application/json",
          "ngrok-skip-browser-warning": "true"
        },
        body: jsonEncode({"id": id}),
      );
      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }

  // 6. ฟังก์ชันแก้ไขสินค้า (คงไว้เพื่อให้ปุ่มแก้ไขทำงานได้)
  Future<bool> updateProduct(
      int id, String name, String price, String qty, String image) async {
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/update_product.php"),
        headers: {
          "Content-Type": "application/json",
          "ngrok-skip-browser-warning": "true"
        },
        body: jsonEncode({
          "id": id,
          "name": name,
          "price": price,
          "qty": qty,
          "image": image // ✅ ส่งลิงก์รูปไปที่ PHP
        }),
      );
      // เช็คว่า PHP ตอบกลับมามีคำว่า success หรือไม่
      return response.statusCode == 200 && response.body.contains("success");
    } catch (e) {
      return false;
    }
  }
}
